# SoundStage Icon Assets

## Package Contents

This package contains all the icon and artwork assets for the SoundStage Android app with a retro-futuristic studio rack aesthetic.

### Included Files:

1. **Adaptive Icons** (Android 8.0+)
   - `mipmap-anydpi-v26/ic_launcher.xml` - Adaptive icon definition
   - `mipmap-anydpi-v26/ic_launcher_round.xml` - Round adaptive icon
   - `drawable/ic_launcher_foreground.xml` - Foreground layer (VU meter, LEDs, controls)
   - `drawable/ic_launcher_background.xml` - Background layer (dark gradient)

2. **Notification Icon**
   - `drawable/ic_notification.xml` - Monochrome notification icon

## Installation Instructions

### For your GitHub repo structure:

Copy the files to your repo following this structure:

```
app/src/main/res/
├── mipmap-anydpi-v26/
│   ├── ic_launcher.xml
│   └── ic_launcher_round.xml
├── drawable/
│   ├── ic_launcher_foreground.xml
│   ├── ic_launcher_background.xml
│   └── ic_notification.xml
```

### Steps via GitHub web interface:

1. Navigate to `app/src/main/res/`

2. Create the `mipmap-anydpi-v26` folder if it doesn't exist:
   - Click "Add file" > "Create new file"
   - In the name field, type: `mipmap-anydpi-v26/ic_launcher.xml`
   - Paste the content from `mipmap-anydpi-v26/ic_launcher.xml`
   - Commit
   - Repeat for `ic_launcher_round.xml`

3. Add drawable resources:
   - Navigate to `app/src/main/res/drawable/`
   - Upload or create each XML file:
     - `ic_launcher_foreground.xml`
     - `ic_launcher_background.xml`
     - `ic_notification.xml`

### Update AndroidManifest.xml

Make sure your `AndroidManifest.xml` references the launcher icon:

```xml
<application
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"
    ...>
```

### Update notification usage

In your `PlaybackService` or notification code, use the notification icon:

```kotlin
val notification = NotificationCompat.Builder(context, CHANNEL_ID)
    .setSmallIcon(R.drawable.ic_notification)
    .setContentTitle("Now Playing")
    // ... other notification settings
    .build()
```

## Design Details

### Color Palette
- **Background**: Dark metallic (#0a0a0a to #1a1a1a)
- **Panel accents**: Medium gray (#333 to #444)
- **LED indicators**: 
  - Green (#00ff00) - Active/good
  - Yellow (#ffff00) - Warning
  - Red (#ff0000) - Peak/error
- **VU meter scale**: Gold (#FFD700) to Red gradient
- **Metal highlights**: Light gray (#888 to #e0e0e0)

### Icon Specifications
- **Adaptive icon safe zone**: 72dp × 72dp (centered in 108dp canvas)
- **Foreground elements**: VU meter, LED matrix, control knobs, fader
- **Background**: Solid dark with subtle texture
- **Notification icon**: 24dp × 24dp monochrome VU needle silhouette

## Additional Notes

- All vector drawables are resolution-independent
- Adaptive icons automatically handle different launcher shapes (circle, squircle, rounded square)
- The notification icon follows Material Design guidelines for status bar visibility
- Icons maintain the vintage studio aesthetic across all contexts

## Feature Graphic

A 1024×500px feature graphic has also been generated for Play Store use. This shows:
- Large VU meter with animated needle
- LED level indicators
- Vintage tape reel transport
- Studio rack controls (knobs, faders, switches)
- "SOUNDSTAGE" branding

Save this separately for Play Store Console uploads.
